quickquest
==========

This program intends to help you to  find files or directories as fast as lightning